# DARIA — Development Intelligence Agent

AI-powered development diplomacy dashboard with live UN ReliefWeb, World Bank & UNDP data.

## Deploy to Vercel (5 minutes, free)

### Step 1 — Upload to GitHub
1. Go to github.com → New repository → name it `daria-agent` → Create
2. Upload all these files (drag & drop the whole folder)

### Step 2 — Deploy on Vercel
1. Go to vercel.com → Sign up free with your GitHub account
2. Click "Add New Project" → Import `daria-agent`
3. Before clicking Deploy, click **Environment Variables**
4. Add: `ANTHROPIC_API_KEY` = your key from console.anthropic.com
5. Click **Deploy**

### Step 3 — Get your URL + QR code
1. Vercel gives you: `https://daria-agent.vercel.app`
2. Go to qr-code-generator.com → paste your URL → download QR code
3. Share it — anyone who scans it gets the live DARIA dashboard

## Get an Anthropic API Key
1. Go to console.anthropic.com
2. Sign up (free) → API Keys → Create Key
3. Copy it → paste into Vercel environment variables

## Local development
```bash
npm install
cp .env.local.example .env.local
# Edit .env.local and add your API key
npm run dev
# Open http://localhost:3000
```

## What DARIA does
- Dashboard with 6 live development projects
- Live UN ReliefWeb situation reports per country
- Live World Bank development indicators
- AI agent chat (Claude) with full portfolio awareness
- One-click diplomatic briefings per project
