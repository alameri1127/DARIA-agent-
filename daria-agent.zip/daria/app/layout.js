import "./globals.css"

export const metadata = {
  title: "DARIA — Development Intelligence Agent",
  description: "AI-powered development diplomacy dashboard",
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.2.0/tabler-icons.min.css" />
      </head>
      <body>{children}</body>
    </html>
  )
}
