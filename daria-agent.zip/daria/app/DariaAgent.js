"use client";
import { useState, useEffect, useRef, useCallback } from "react";

const PROJECTS = [
  { id:1, name:"Sudan Food Security Initiative", country:"Sudan", iso2:"SD", region:"East Africa", sector:"Agriculture / Humanitarian", status:"At Risk", budget:12500000, spent:4100000, progress:33, partner:"WFP", sdgs:["SDG 2","SDG 1"], description:"Emergency agriculture and food distribution program targeting 3 conflict-affected regions.", flags:["Delayed procurement","Security constraints in Darfur"], endDate:"2026-02-28" },
  { id:2, name:"Rwanda Digital Infrastructure", country:"Rwanda", iso2:"RW", region:"East Africa", sector:"Technology / Education", status:"On Track", budget:8000000, spent:5200000, progress:65, partner:"UNDP", sdgs:["SDG 4","SDG 9","SDG 8"], description:"Expanding broadband connectivity and digital literacy across 500 rural schools.", flags:[], endDate:"2025-12-31" },
  { id:3, name:"Bangladesh Climate Resilience", country:"Bangladesh", iso2:"BD", region:"South Asia", sector:"Climate / Infrastructure", status:"On Track", budget:22000000, spent:7800000, progress:35, partner:"World Bank", sdgs:["SDG 13","SDG 11","SDG 6"], description:"Flood resilience infrastructure and early warning systems in coastal zones.", flags:[], endDate:"2027-01-14" },
  { id:4, name:"Morocco Renewable Energy Access", country:"Morocco", iso2:"MA", region:"North Africa", sector:"Energy", status:"Delayed", budget:15000000, spent:1200000, progress:8, partner:"IRENA", sdgs:["SDG 7","SDG 13"], description:"Solar micro-grid deployment for 200 off-grid villages in Atlas Mountain region.", flags:["Contractor dispute","Permit delays from local authority"], endDate:"2026-12-31" },
  { id:5, name:"Pakistan Education Emergency", country:"Pakistan", iso2:"PK", region:"South Asia", sector:"Education / Humanitarian", status:"On Track", budget:9500000, spent:6700000, progress:70, partner:"UNICEF", sdgs:["SDG 4","SDG 5"], description:"Temporary learning centers and teacher training for flood-affected communities.", flags:[], endDate:"2025-04-30" },
  { id:6, name:"Kenya Health Systems Strengthening", country:"Kenya", iso2:"KE", region:"East Africa", sector:"Health", status:"On Track", budget:18000000, spent:9100000, progress:50, partner:"WHO", sdgs:["SDG 3"], description:"Primary healthcare capacity building and supply chain management in rural counties.", flags:[], endDate:"2026-10-31" },
];

const SUGGESTIONS = [
  { icon:"ti-alert-triangle", label:"Which projects need urgent attention?", color:"#854F0B" },
  { icon:"ti-file-text", label:"Brief me on the Sudan project", color:"#185FA5" },
  { icon:"ti-chart-bar", label:"Summarise portfolio performance", color:"#3B6D11" },
  { icon:"ti-map-pin", label:"Situation in East Africa right now?", color:"#534AB7" },
  { icon:"ti-bulb", label:"Where should we invest next?", color:"#0F6E56" },
  { icon:"ti-clock", label:"Which projects are behind schedule?", color:"#A32D2D" },
];

const STATUS = {
  "On Track": { bg:"#EAF3DE", color:"#3B6D11", bar:"#639922", border:"#639922" },
  "At Risk":  { bg:"#FAEEDA", color:"#854F0B", bar:"#EF9F27", border:"#EF9F27" },
  "Delayed":  { bg:"#FCEBEB", color:"#A32D2D", bar:"#E24B4A", border:"#E24B4A" },
};

const fmt = n => n>=1e9?"$"+(n/1e9).toFixed(1)+"B":n>=1e6?"$"+(n/1e6).toFixed(1)+"M":n>=1e3?"$"+(n/1e3).toFixed(0)+"K":"$"+n;

async function fetchReliefWeb(country) {
  try {
    const r = await fetch(`https://api.reliefweb.int/v1/reports?appname=devtracker&filter[field]=country.name&filter[value]=${encodeURIComponent(country)}&fields[include][]=title&fields[include][]=date.created&fields[include][]=source.name&sort[]=date.created:desc&limit=3`);
    const d = await r.json();
    return (d.data||[]).map(x=>({ title:x.fields.title, date:(x.fields.date?.created||"").slice(0,10), source:x.fields.source?.[0]?.name||"ReliefWeb" }));
  } catch { return []; }
}

async function fetchWorldBank(iso2) {
  try {
    const ids = "NY.GDP.PCAP.CD;SP.POP.TOTL;SI.POV.NAHC;SH.XPD.CHEX.GD.ZS";
    const r = await fetch(`https://api.worldbank.org/v2/country/${iso2}/indicator/${ids}?format=json&mrv=1&per_page=10`);
    const d = await r.json();
    const map = { "NY.GDP.PCAP.CD":"GDP per capita (USD)", "SP.POP.TOTL":"Population", "SI.POV.NAHC":"Poverty rate (%)", "SH.XPD.CHEX.GD.ZS":"Health spend (% GDP)" };
    const out = {};
    (d[1]||[]).forEach(row => { if (row.value !== null && map[row.indicator.id]) out[map[row.indicator.id]] = { value: row.value, year: row.date }; });
    return out;
  } catch { return {}; }
}

function StatusBadge({ status }) {
  const s = STATUS[status] || STATUS["On Track"];
  return (
    <span style={{ fontSize:11, fontWeight:600, padding:"3px 8px", borderRadius:99, background:s.bg, color:s.color, border:`0.5px solid ${s.border}`, whiteSpace:"nowrap" }}>
      {status}
    </span>
  );
}

function ProgressBar({ value, status }) {
  const s = STATUS[status] || STATUS["On Track"];
  return (
    <div style={{ height:5, background:"#e8e8e4", borderRadius:99, overflow:"hidden", marginTop:4 }}>
      <div style={{ width:`${value}%`, height:"100%", background:s.bar, borderRadius:99 }} />
    </div>
  );
}

function renderMarkdown(text) {
  return text.split("\n").map((line, i) => {
    if (line.startsWith("**") && line.endsWith("**")) return <div key={i} style={{ fontWeight:600, fontSize:13, marginTop:i>0?10:0, marginBottom:3 }}>{line.replace(/\*\*/g,"")}</div>;
    if (/\*\*/.test(line)) {
      const parts = line.split(/\*\*(.+?)\*\*/g);
      return <div key={i} style={{ marginBottom:2 }}>{parts.map((p,j)=>j%2===1?<strong key={j}>{p}</strong>:p)}</div>;
    }
    if (line.startsWith("- ") || line.startsWith("• ")) return (
      <div key={i} style={{ display:"flex", gap:8, marginBottom:3, paddingLeft:4 }}>
        <span style={{ color:"#1D9E75", fontWeight:600, flexShrink:0 }}>·</span>
        <span>{line.slice(2).replace(/\*\*/g,"")}</span>
      </div>
    );
    if (line.trim()==="") return <div key={i} style={{ height:6 }} />;
    return <div key={i} style={{ marginBottom:2 }}>{line.replace(/\*\*/g,"")}</div>;
  });
}

export default function DariaAgent() {
  const [view, setView] = useState("dashboard");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [liveCache, setLiveCache] = useState({});
  const [dataStatus, setDataStatus] = useState("loading");
  const [alerts, setAlerts] = useState([]);
  const chatEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    const countries = [...new Set(PROJECTS.map(p => p.country))];
    const pairs = countries.map(c => ({ country: c, iso2: PROJECTS.find(p=>p.country===c).iso2 }));
    Promise.all(pairs.map(async ({country, iso2}) => {
      const [rw, wb] = await Promise.all([fetchReliefWeb(country), fetchWorldBank(iso2)]);
      return { country, rw, wb };
    })).then(results => {
      const cache = {};
      const alertList = [];
      results.forEach(({country, rw, wb}) => {
        cache[country] = { reliefweb: rw, worldbank: wb };
        if (rw.length > 0) alertList.push({ country, ...rw[0] });
      });
      setLiveCache(cache);
      setAlerts(alertList.slice(0, 4));
      setDataStatus("ready");
    });
  }, []);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior:"smooth" }); }, [messages]);

  const buildSystem = useCallback(() => {
    const portfolio = PROJECTS.map(p=>`[${p.id}] ${p.name} | ${p.country} | ${p.sector} | ${p.status} | Budget:${fmt(p.budget)} Spent:${fmt(p.spent)} (${p.progress}%) | Partner:${p.partner} | Flags:${p.flags.join(";")||"None"} | Ends:${p.endDate}`).join("\n");
    let live = "";
    Object.entries(liveCache).forEach(([country,data]) => {
      live += `\n### ${country}\n`;
      if (data.reliefweb?.length>0) { live+="UN reports:\n"; data.reliefweb.forEach(r=>live+=`  - ${r.title} (${r.source}, ${r.date})\n`); }
      if (Object.keys(data.worldbank||{}).length>0) { live+="World Bank:\n"; Object.entries(data.worldbank).forEach(([k,v])=>live+=`  - ${k}: ${v.value>1000?Number(v.value).toLocaleString():Number(v.value).toFixed(1)} (${v.year})\n`); }
    });
    return `You are DARIA — Development Aid & Research Intelligence Agent — senior AI advisor for a UAE development authority. You have full access to the portfolio and live country intelligence below. Be concise, analytical, direct. Use **bold headers** and - bullet points.\n\n## PORTFOLIO\n${portfolio}\n\n## LIVE INTELLIGENCE${live||"\n(Loading…)"}\n\nDate: ${new Date().toISOString().slice(0,10)}`;
  }, [liveCache]);

  const sendChat = useCallback(async (text) => {
    const msg = text || input.trim();
    if (!msg || loading) return;
    setInput("");
    setView("chat");
    setLoading(true);

    const userMsg = { role:"user", content:msg };
    setMessages(prev => [...prev, userMsg, { role:"assistant", content:"__thinking__" }]);

    const history = [...messages, userMsg].map(m => ({ role:m.role, content:m.content }));

    try {
      const res = await fetch("/api/chat", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:1000, system:buildSystem(), messages:history }),
      });
      const data = await res.json();
      const reply = data.content?.map(b=>b.type==="text"?b.text:"").join("\n") || "Sorry, I couldn't generate a response.";
      setMessages(prev => [...prev.filter(m=>m.content!=="__thinking__"), { role:"assistant", content:reply, time:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}) }]);
    } catch {
      setMessages(prev => [...prev.filter(m=>m.content!=="__thinking__"), { role:"assistant", content:"Connection error — please try again." }]);
    }
    setLoading(false);
    setTimeout(() => inputRef.current?.focus(), 100);
  }, [input, loading, messages, buildSystem]);

  const handleKey = (e) => { if (e.key==="Enter" && !e.shiftKey) { e.preventDefault(); sendChat(); } };

  const totalBudget = PROJECTS.reduce((s,p)=>s+p.budget,0);
  const totalSpent  = PROJECTS.reduce((s,p)=>s+p.spent,0);
  const atRisk      = PROJECTS.filter(p=>p.status!=="On Track").length;
  const msgCount    = messages.filter(m=>m.content!=="__thinking__").length;

  const NAV = { borderBottom:"1px solid #e8e8e4", display:"flex", alignItems:"center", gap:4, padding:"0 16px", height:52, background:"#fff", flexShrink:0 };
  const navBtn = (active) => ({ background:active?"#f0f0ec":"none", border:"none", display:"flex", alignItems:"center", gap:5, padding:"7px 12px", borderRadius:8, fontSize:13, color:active?"#1a1a18":"#666", fontWeight:active?500:400, cursor:"pointer" });

  return (
    <div style={{ display:"flex", flexDirection:"column", height:"100vh", background:"#f8f8f6" }}>
      <style>{`
        .dot{width:5px;height:5px;border-radius:50%;background:#aaa;display:inline-block;animation:blink 1.2s infinite}
        .dot:nth-child(2){animation-delay:.2s}.dot:nth-child(3){animation-delay:.4s}
        @keyframes blink{0%,80%,100%{opacity:.3;transform:scale(0.8)}40%{opacity:1;transform:scale(1)}}
        .proj-row{display:grid;grid-template-columns:2fr 1fr 1fr 90px;gap:10px;align-items:center;padding:10px 16px;border-bottom:1px solid #f0f0ec;cursor:pointer;transition:background 0.12s}
        .proj-row:last-child{border-bottom:none}.proj-row:hover{background:#fafaf8}
        .chip{background:#f5f5f1;border:1px solid #e8e8e4;border-radius:8px;padding:8px 12px;font-size:12px;cursor:pointer;text-align:left;transition:all 0.12s;display:flex;align-items:center;gap:8px;font-family:inherit;color:#1a1a18;width:100%}
        .chip:hover{border-color:#ccc;background:#fff}
        .msg-user{display:flex;justify-content:flex-end;margin-bottom:14px}
        .msg-agent{display:flex;gap:8px;align-items:flex-start;margin-bottom:14px}
        .send-btn{width:32px;height:32px;border-radius:50%;background:#1D9E75;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:opacity 0.15s}
        .send-btn:disabled{background:#ccc;cursor:default}
        textarea{flex:1;background:none;border:none;outline:none;resize:none;font-size:13px;line-height:1.5;font-family:inherit;color:#1a1a18;max-height:100px;overflow-y:auto}
        textarea::placeholder{color:#aaa}
      `}</style>

      {/* Nav */}
      <div style={NAV}>
        <div style={{ display:"flex", alignItems:"center", gap:8, marginRight:16 }}>
          <div style={{ width:28, height:28, borderRadius:"50%", background:"#1D9E75", display:"flex", alignItems:"center", justifyContent:"center" }}>
            <i className="ti ti-world" style={{ fontSize:14, color:"#fff" }} />
          </div>
          <span style={{ fontWeight:600, fontSize:14 }}>DARIA</span>
          <span style={{ fontSize:11, color:"#aaa" }}>· Development Intelligence Agent</span>
        </div>
        <button style={navBtn(view==="dashboard")} onClick={()=>setView("dashboard")}>
          <i className="ti ti-layout-dashboard" style={{ fontSize:14 }} />Dashboard
        </button>
        <button style={navBtn(view==="chat")} onClick={()=>setView("chat")}>
          <i className="ti ti-message-circle" style={{ fontSize:14 }} />Agent Chat
          {msgCount > 0 && <span style={{ background:"#185FA5", color:"#fff", borderRadius:99, fontSize:10, padding:"1px 5px", fontWeight:600 }}>{msgCount}</span>}
        </button>
        <div style={{ marginLeft:"auto", display:"flex", alignItems:"center", gap:6, fontSize:11, color:dataStatus==="ready"?"#3B6D11":"#aaa" }}>
          <span style={{ width:6, height:6, borderRadius:"50%", background:dataStatus==="ready"?"#639922":"#EF9F27", display:"inline-block" }} />
          {dataStatus==="ready" ? "Live data ready" : "Fetching live data…"}
        </div>
      </div>

      {/* Dashboard */}
      {view==="dashboard" && (
        <div style={{ flex:1, overflowY:"auto", padding:16, display:"flex", flexDirection:"column", gap:14 }}>

          {/* Metrics */}
          <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:10 }}>
            {[
              { label:"Total portfolio", value:fmt(totalBudget), sub:`${PROJECTS.length} projects`, icon:"ti-chart-bar", accent:"#185FA5" },
              { label:"Disbursed", value:fmt(totalSpent), sub:`${Math.round(totalSpent/totalBudget*100)}% utilisation`, icon:"ti-coin", accent:"#1D9E75" },
              { label:"Needs attention", value:atRisk, sub:"at risk or delayed", icon:"ti-alert-triangle", accent:"#EF9F27" },
              { label:"Live sources", value:"3", sub:"ReliefWeb · WB · UNDP", icon:"ti-database", accent:"#534AB7" },
            ].map(m => (
              <div key={m.label} style={{ background:"#fff", border:"1px solid #ebebeb", borderRadius:10, padding:"12px 14px" }}>
                <div style={{ display:"flex", alignItems:"center", gap:5, marginBottom:6, fontSize:11, color:"#888" }}>
                  <i className={`ti ${m.icon}`} style={{ fontSize:13, color:m.accent }} />{m.label}
                </div>
                <div style={{ fontSize:22, fontWeight:600, lineHeight:1 }}>{m.value}</div>
                <div style={{ fontSize:10, color:"#aaa", marginTop:3 }}>{m.sub}</div>
              </div>
            ))}
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"1.5fr 1fr", gap:14 }}>
            {/* Projects */}
            <div style={{ background:"#fff", border:"1px solid #ebebeb", borderRadius:12, overflow:"hidden" }}>
              <div style={{ padding:"10px 16px", borderBottom:"1px solid #f0f0ec", fontSize:12, fontWeight:500, display:"flex", alignItems:"center", gap:6 }}>
                <i className="ti ti-list" style={{ fontSize:13, color:"#888" }} />Active projects
                <span style={{ marginLeft:"auto", fontSize:10, color:"#aaa" }}>Click a row to brief DARIA</span>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"2fr 1fr 1fr 90px", gap:10, padding:"7px 16px", borderBottom:"1px solid #f0f0ec" }}>
                {["Project","Budget","Progress","Status"].map(h=><div key={h} style={{ fontSize:10, fontWeight:600, color:"#aaa", textTransform:"uppercase", letterSpacing:"0.05em" }}>{h}</div>)}
              </div>
              {PROJECTS.map(p => (
                <div key={p.id} className="proj-row" onClick={()=>sendChat(`Give me a full briefing on the ${p.name} project — current risks, live country context, and recommendations.`)}>
                  <div>
                    <div style={{ fontWeight:500, fontSize:13 }}>{p.name}</div>
                    <div style={{ fontSize:11, color:"#888", marginTop:1 }}>{p.country} · {p.partner}</div>
                    {p.flags.length>0 && <div style={{ fontSize:10, color:"#854F0B", marginTop:2 }}>⚠ {p.flags[0]}</div>}
                  </div>
                  <div style={{ fontSize:12 }}>
                    <div style={{ fontWeight:500 }}>{fmt(p.budget)}</div>
                    <div style={{ color:"#aaa", fontSize:10 }}>{fmt(p.spent)} spent</div>
                  </div>
                  <div>
                    <div style={{ fontSize:10, color:"#888" }}>{p.progress}%</div>
                    <ProgressBar value={p.progress} status={p.status} />
                  </div>
                  <StatusBadge status={p.status} />
                </div>
              ))}
            </div>

            {/* Right column */}
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              {/* Ask DARIA */}
              <div style={{ background:"#fff", border:"1px solid #ebebeb", borderRadius:12, overflow:"hidden" }}>
                <div style={{ padding:"10px 14px", borderBottom:"1px solid #f0f0ec", fontSize:12, fontWeight:500, display:"flex", alignItems:"center", gap:6 }}>
                  <div style={{ width:18, height:18, borderRadius:"50%", background:"#1D9E75", display:"flex", alignItems:"center", justifyContent:"center" }}>
                    <i className="ti ti-robot" style={{ fontSize:10, color:"#fff" }} />
                  </div>
                  Ask DARIA
                </div>
                <div style={{ padding:"10px 12px", display:"flex", flexDirection:"column", gap:5 }}>
                  {SUGGESTIONS.map((s,i) => (
                    <button key={i} className="chip" onClick={()=>sendChat(s.label)}>
                      <i className={`ti ${s.icon}`} style={{ fontSize:12, color:s.color, flexShrink:0 }} />{s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Live alerts */}
              <div style={{ background:"#fff", border:"1px solid #ebebeb", borderRadius:12, overflow:"hidden" }}>
                <div style={{ padding:"10px 14px", borderBottom:"1px solid #f0f0ec", fontSize:12, fontWeight:500, display:"flex", alignItems:"center", gap:6 }}>
                  <i className="ti ti-news" style={{ fontSize:13, color:"#185FA5" }} />UN ReliefWeb · Latest
                </div>
                <div style={{ padding:"10px 14px", display:"flex", flexDirection:"column", gap:10 }}>
                  {dataStatus==="loading" ? (
                    <div style={{ fontSize:11, color:"#aaa", display:"flex", alignItems:"center", gap:6 }}>
                      <span className="dot" /><span className="dot" /><span className="dot" />
                      <span style={{ marginLeft:4 }}>Fetching live reports…</span>
                    </div>
                  ) : alerts.map((a,i) => (
                    <div key={i} style={{ paddingLeft:8, borderLeft:"2px solid #e0e0e0" }}>
                      <div style={{ fontSize:10, fontWeight:600, color:"#185FA5", marginBottom:2 }}>{a.country}</div>
                      <div style={{ fontSize:11, color:"#555", lineHeight:1.4 }}>{a.title}</div>
                      <div style={{ fontSize:10, color:"#aaa", marginTop:1 }}>{a.source} · {a.date}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Chat */}
      {view==="chat" && (
        <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
          <div style={{ padding:"6px 16px", borderBottom:"1px solid #f0f0ec", display:"flex", alignItems:"center", gap:6, fontSize:10, color:"#888", background:"#fff", flexShrink:0 }}>
            <span>Live:</span>
            {["UN ReliefWeb","World Bank","UNDP"].map(s=>(
              <span key={s} style={{ padding:"2px 7px", border:"1px solid #e8e8e4", borderRadius:99, color:"#555" }}>{s}</span>
            ))}
          </div>

          <div style={{ flex:1, overflowY:"auto", padding:16 }}>
            {messages.length===0 && (
              <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", minHeight:360, gap:14, textAlign:"center" }}>
                <div style={{ width:50, height:50, borderRadius:"50%", background:"#1D9E75", display:"flex", alignItems:"center", justifyContent:"center" }}>
                  <i className="ti ti-robot" style={{ fontSize:24, color:"#fff" }} />
                </div>
                <div>
                  <div style={{ fontWeight:600, fontSize:15, marginBottom:4 }}>DARIA is ready</div>
                  <div style={{ fontSize:12, color:"#888", maxWidth:320, lineHeight:1.5 }}>Full awareness of your 6 projects and live intelligence from UN ReliefWeb, World Bank & UNDP.</div>
                </div>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:7, maxWidth:440, width:"100%" }}>
                  {SUGGESTIONS.slice(0,4).map((s,i) => (
                    <button key={i} className="chip" onClick={()=>sendChat(s.label)}>
                      <i className={`ti ${s.icon}`} style={{ fontSize:12, color:s.color }} />{s.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((m,i) => m.content==="__thinking__" ? (
              <div key={i} className="msg-agent">
                <div style={{ width:26, height:26, borderRadius:"50%", background:"#1D9E75", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, marginTop:2 }}>
                  <i className="ti ti-robot" style={{ fontSize:12, color:"#fff" }} />
                </div>
                <div style={{ background:"#f5f5f1", borderRadius:"0 10px 10px 10px", padding:"10px 14px", fontSize:12, color:"#888", display:"flex", alignItems:"center", gap:8 }}>
                  <span className="dot" /><span className="dot" /><span className="dot" />
                  <span style={{ marginLeft:4 }}>DARIA is thinking…</span>
                </div>
              </div>
            ) : m.role==="user" ? (
              <div key={i} className="msg-user">
                <div style={{ background:"#185FA5", color:"#fff", borderRadius:"10px 10px 0 10px", padding:"9px 13px", fontSize:12, maxWidth:"80%", lineHeight:1.6 }}>
                  {m.content}
                </div>
              </div>
            ) : (
              <div key={i} className="msg-agent">
                <div style={{ width:26, height:26, borderRadius:"50%", background:"#1D9E75", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, marginTop:2 }}>
                  <i className="ti ti-robot" style={{ fontSize:12, color:"#fff" }} />
                </div>
                <div style={{ background:"#f5f5f1", borderRadius:"0 10px 10px 10px", padding:"10px 14px", fontSize:12, lineHeight:1.7, maxWidth:"88%", flex:1 }}>
                  {renderMarkdown(m.content)}
                  {m.time && <div style={{ fontSize:9, color:"#aaa", marginTop:6 }}>{m.time}</div>}
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>

          <div style={{ padding:"10px 14px", borderTop:"1px solid #f0f0ec", background:"#fff", flexShrink:0 }}>
            <div style={{ display:"flex", gap:8, alignItems:"flex-end", background:"#f5f5f1", borderRadius:10, border:"1px solid #e0e0e0", padding:"8px 8px 8px 14px" }}>
              <textarea ref={inputRef} value={input} onChange={e=>setInput(e.target.value)} onKeyDown={handleKey}
                rows={1} placeholder="Ask about projects, risks, briefs, country intelligence…"
                onInput={e=>{ e.target.style.height="auto"; e.target.style.height=Math.min(e.target.scrollHeight,100)+"px"; }}
              />
              <button className="send-btn" onClick={()=>sendChat()} disabled={loading||!input.trim()} aria-label="Send">
                <i className="ti ti-send" style={{ fontSize:13, color:"#fff" }} />
              </button>
            </div>
            <div style={{ fontSize:10, color:"#bbb", marginTop:5, textAlign:"center" }}>
              DARIA · Powered by Claude + UN ReliefWeb + World Bank + UNDP · Enter to send
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
