import DariaAgent from "./DariaAgent"

export default function Home() {
  return <DariaAgent />
}
